# import boto3
# import json

# def lambda_handler(event, context):
#     # Connect to DynamoDB
#     dynamodb = boto3.resource("dynamodb")
#     table = dynamodb.Table("VisitorCounter")  # Update to your table name

#     # Define the partition key
#     visitor_id = "count"  # This should match the value you use as the key in DynamoDB

#     # Get the current view count
#     response = table.get_item(Key={"VisitorId": visitor_id})
#     item = response.get("Item", {})
    
#     # Get the current view count or initialize to 0 if it doesn't exist
#     view_count = item.get("visitor_count", 0)

#     # Increment the view count
#     view_count += 1

#     # Update the view count in DynamoDB
#     table.put_item(Item={"VisitorId": visitor_id, "visitor_count": view_count})

#     # Return the updated view count
#     return {
#         "statusCode": 200,
#         "body": json.dumps({"count": view_count}),  # Return count as JSON
#         "headers": {
#             'Content-Type': 'application/json',
#         }
#     }
    
    
# import json
# import boto3

# def lambda_handler(event, context):
#     # Initialize DynamoDB resource
#     dynamodb = boto3.resource("dynamodb")
#     table = dynamodb.Table("VisitorCounter")  # DynamoDB table name

#     # Use a fixed VisitorId, as we're only tracking total visitors
#     visitor_id = "count"

#     # Get the current count from DynamoDB
#     response = table.get_item(Key={"VisitorId": visitor_id})
#     item = response.get("Item", {})

#     # Get current count or initialize to 0 if it doesn't exist
#     view_count = item.get("visitor_count", 0)

#     # Increment the view count
#     view_count += 1

#     # Update the count in DynamoDB
#     table.put_item(Item={"VisitorId": visitor_id, "visitor_count": view_count})




#     # Return the updated count as the response
#     return {
#         "statusCode": 200,
#         "body": json.dumps({"count": view_count}),
#         "headers": {
#             'Content-Type': 'application/json',
#             'Access-Control-Allow-Origin': '*',  # For CORS
#         }
#     }
    
import boto3
from botocore.exceptions import ClientError

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table("VisitorCounter")  # Replace with your table name

# Define partition key (no sort key needed)
partition_key = "VisitorId"
partition_value = "count"  # Assuming you are using a fixed VisitorId for counting

try:
    # Update the view_count field by incrementing it
    response = table.update_item(
        Key={partition_key: partition_value},
        UpdateExpression="SET visitor_count = if_not_exists(visitor_count, :start) + :inc",  # Use 'if_not_exists' to handle first-time entries
        ExpressionAttributeValues={
            ':start': 0,  # Initialize to 0 if it doesn't exist
            ':inc': 1  # Increment by 1
        },
        ReturnValues="UPDATED_NEW"  # Return the updated value
    )

    # Print the updated visitor count
    print(f"New visitor count: {response['Attributes']['visitor_count']}")

except ClientError as e:
    print("Error:", e.response['Error']['Message'])
    
    
    
